# color-detect-in-image
Python programming For detection of color in an Image

Requirement 
1)Opencv
https://sourceforge.net/projects/opencvlibrary/
2)Python2.7
https://www.python.org/downloads/release/python-2711/
3)Numpy for python 2.7
https://pypi.python.org/pypi/numpy


Source Code with Proper instruction For Windows  system
https://github.com/JayMishra7/color-detect-in-image/blob/Output-Images/instruction.docx

Original image :https://github.com/JayMishra7/color-detect-in-image/blob/Output-Images/pokemon_games.png

Output Images
1)https://github.com/JayMishra7/color-detect-in-image/blob/Output-Images/1.JPG
2)https://github.com/JayMishra7/color-detect-in-image/blob/Output-Images/2.JPG
3)https://github.com/JayMishra7/color-detect-in-image/blob/Output-Images/3.JPG
4)https://github.com/JayMishra7/color-detect-in-image/blob/Output-Images/4.JPG

Source Code with Proper instruction For unix system
http://www.pyimagesearch.com/2014/08/04/opencv-python-color-detection

for more info Feel Free To Contact me
Please give comments and reviews 
